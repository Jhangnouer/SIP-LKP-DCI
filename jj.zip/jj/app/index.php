<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">

<head>
    <?php include 'templete/header.php' ?>
    <?php include '../conf/config.php' ?>
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="js-sidebar">
            <!-- Content For Sidebar -->
            <?php include 'templete/sidebar.php' ?>
        </aside>
        <div class="main">
            <?php include 'templete/navbar.php' ?>
            <main class="content px-3 py-2">
                <div class="container-fluid">
                    <div class="mb-3">
                       
                    </div>
                    <?php
                    $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
                    // Menyesuaikan file yang di-include berdasarkan parameter page
                    switch ($page) {
                        case 'dashboard':
                            include '../app/pages/dashboard.php';
                            break;
                        case 'kursus':
                            include '../app/pages/kursus.php';
                            break;
                        case 'instruktur':
                            include '../app/pages/instruktur.php';
                            break;
                        case 'peserta':
                            include '../app/pages/peserta.php';
                            break;
                        case 'pendaftaran':
                            include '../app/pages/pendaftaran.php';
                            break;
                        case 'keuangan':
                            include '../app/pages/invoice.php';
                            break;
                        default:
                            echo "Halaman tidak ditemukan";
                            break;
                    }
                    ?>
                    <!-- Table Element -->

                </div>
            </main>
            <a href="#" class="theme-toggle">
                <i class="fa-regular fa-moon"></i>
                <i class="fa-regular fa-sun"></i>
            </a>
            <?php include 'templete/footer.php' ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>