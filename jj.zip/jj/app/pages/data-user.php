<?php
include 'templete/header.php';
include 'templete/sidebar.php';
include 'templete/navbar.php';
?>

<main class="content px-3 py-2">
    <div class="container-fluid">
        <div class="mb-3">
            <h4>Pendaftaran Kursus - Admin Dashboard</h4>
        </div>

        <!-- Table Element -->
        <div class="card border-0">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title">
                    Data Pendaftaran
                </h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama Lengkap</th>
                            <th scope="col">Nomor KTP/NIK</th>
                            <th scope="col">Tempat Lahir</th>
                            <th scope="col">Tanggal Lahir</th>
                            <th scope="col">Jenis Kelamin</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">Kode Pos</th>
                            <th scope="col">Email</th>
                            <th scope="col">Pendidikan Terakhir</th>
                            <th scope="col">Pekerjaan</th>
                            <th scope="col">Jabatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Gantilah data berikut sesuai dengan data yang ingin ditampilkan -->
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>1234567890</td>
                            <td>New York</td>
                            <td>2022-01-01</td>
                            <td>Laki-laki</td>
                            <td>123 Street, City</td>
                            <td>12345</td>
                            <td>mark@example.com</td>
                            <td>S1 Teknik Informatika</td>
                            <td>Software Engineer</td>
                            <td>Lead Developer</td>
                        </tr>
                        <!-- Contoh data tambahan -->
                        <tr>
                            <th scope="row">2</th>
                            <td>Jane</td>
                            <td>0987654321</td>
                            <td>Los Angeles</td>
                            <td>2022-02-02</td>
                            <td>Perempuan</td>
                            <td>456 Avenue, Town</td>
                            <td>54321</td>
                            <td>jane@example.com</td>
                            <td>D3 Manajemen</td>
                            <td>Marketing Specialist</td>
                            <td>Manager</td>
                        </tr>
                        <!-- Data lainnya -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<a href="#" class="theme-toggle">
    <i class="fa-regular fa-moon"></i>
    <i class="fa-regular fa-sun"></i>
</a>

<?php include 'templete/footer.php' ?>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
