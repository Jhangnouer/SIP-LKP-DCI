<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pendaftaran</title>
    <!-- Bootstrap CSS (example, adjust if using a different framework or custom styles) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            padding-top: 56px; /* Adjust based on your navbar height */
        }

        .sidebar {
            position: fixed;
            width: 250px;
            height: 100%;
            background-color: #f8f9fa; /* Adjust the background color */
            padding: 20px;
        }

        .content {
            margin-left: 250px; /* Set equal to the sidebar width */
            padding: 20px;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <?php include '../../app/templete/sidebar.php'; ?>
            </div>

            <!-- Main content -->
            <div class="col-md-9 content">
                <div class="card border-0">
                    <div class="card-header">
                        <h5 class="card-title">
                            Data Pendaftaran
                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">First</th>
                                    <th scope="col">Last</th>
                                    <th scope="col">Handle</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Your table content goes here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (example, adjust if using a different framework or custom scripts) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.8/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <?php include '../../app/templete/footer.php'; ?>
</body>

</html>
